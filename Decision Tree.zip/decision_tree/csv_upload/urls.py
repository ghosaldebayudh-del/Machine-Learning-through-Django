from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path("", views.file_upload, name="file_upload"),
    path("analyze/", views.analyze_report, name="analyze_report"),
    path("predict/", views.predict_flower, name="predict_flower"),
]
