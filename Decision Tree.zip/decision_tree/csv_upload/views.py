from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponse, JsonResponse
from pandas_fileUpload import settings
from django.core.paginator import Paginator
from ml.train_model import train_model

import os
import pandas as pd
import pickle
from pathlib import Path
from .forms import PredictionForm

context = {}

# Project Root
BASE_DIR = Path(__file__).resolve().parent.parent


def home(request):
    return render(request, "csv_uplaod/csv_upload.html")


def file_upload(request):
    if request.method == "POST" and request.FILES.get("csv_file"):
        upload_file = request.FILES["csv_file"]

        save_path = os.path.join(settings.MEDIA_ROOT, upload_file.name)

        with open(save_path, mode="wb+") as dest:
            for chunk in upload_file.chunks():
                dest.write(chunk)

        # Save the uploaded CSV path in session
        request.session["csv_path"] = save_path

        # Remove stale model file to force retraining on the new dataset
        model_path = os.path.join(settings.BASE_DIR, "ml", "model.pkl")
        if os.path.exists(model_path):
            try:
                os.remove(model_path)
            except Exception as e:
                print(f"Error removing stale model: {e}")

        df = pd.read_csv(save_path)

        target_column = df.columns[-1]
        category = df[target_column].dropna().unique().tolist()

        return JsonResponse({
            "status": True,
            "category": category,
            "file_name": upload_file.name,
            "message": "File uploaded successfully",
        })

    return JsonResponse({
        "status": False,
        "message": "No file uploaded"
    })


def analyze_report(request):
    if request.method == "POST":
        select_category = request.POST.get("category")
        file_name = request.POST.get("file_name")

        # Get current page from AJAX request
        page_number = request.POST.get("page", 1)

        file_path = os.path.join(settings.MEDIA_ROOT, file_name)

        df = pd.read_csv(file_path)
        target_column = df.columns[-1]
        filtered_df = df[df[target_column] == select_category]

        # Remove species column
        filtered_df = filtered_df.drop(columns=[target_column])
        columns = filtered_df.columns.tolist()

        column_mapping = {
            "sepal_length": "Sepal Length",
            "sepal_width": "Sepal Width",
            "petal_length": "Petal Length",
            "petal_width": "Petal Width",
            "SepalLengthCm": "Sepal Length",
            "SepalWidthCm": "Sepal Width",
            "PetalLengthCm": "Petal Length",
            "PetalWidthCm": "Petal Width",
            "Id": "Id",
            "id": "Id"
        }

        display_columns = [column_mapping.get(column, column) for column in columns]
        records = filtered_df.to_dict(orient="records")

        # Pagination
        paginator = Paginator(records, 10)  # 10 records per page
        page_obj = paginator.get_page(page_number)

        return JsonResponse({
            "status": True,
            "columns": columns,
            "display_columns": display_columns,
            "records": list(page_obj),
            "current_page": page_obj.number,
            "total_pages": paginator.num_pages,
            "has_next": page_obj.has_next(),
            "has_previous": page_obj.has_previous(),
            "message": "Report Analyzed successfully",
        })

    return JsonResponse({
        "status": False,
        "message": "Invalid Request"
    })


def predict_flower(request):
    if request.method == "POST":
        form = PredictionForm(request.POST)
        csv_path = request.session.get("csv_path")

        if form.is_valid():
            model_path = os.path.join(settings.BASE_DIR, "ml", "model.pkl")

            # Train model only if it doesn't exist
            if not os.path.exists(model_path):
                model = train_model(csv_path)
            else:
                with open(model_path, "rb") as file:
                    model = pickle.load(file)

            prediction = model.predict([[
                form.cleaned_data["sepal_length"],
                form.cleaned_data["sepal_width"],
                form.cleaned_data["petal_length"],
                form.cleaned_data["petal_width"]
            ]])

            return JsonResponse({
                "status": True,
                "prediction": prediction[0]
            })

        return JsonResponse({
            "status": False,
            "errors": form.errors
        })

    return JsonResponse({
        "status": False,
        "errors": "Invalid Request"
    })
