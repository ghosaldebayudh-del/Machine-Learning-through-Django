from django import forms


class PredictionForm(forms.Form):

    sepal_length = forms.FloatField()
    sepal_width = forms.FloatField()
    petal_length = forms.FloatField()
    petal_width = forms.FloatField()

    def clean_sepal_length(self):
        value = self.cleaned_data["sepal_length"]

        if value < 4.3 or value > 7.9:
            raise forms.ValidationError(
                "Sepal Length must be between 4.3 and 7.9."
            )

        return value

    def clean_sepal_width(self):
        value = self.cleaned_data["sepal_width"]

        if value < 2.0 or value > 4.4:
            raise forms.ValidationError(
                "Sepal Width must be between 2.0 and 4.4."
            )

        return value

    def clean_petal_length(self):
        value = self.cleaned_data["petal_length"]

        if value < 1.0 or value > 6.9:
            raise forms.ValidationError(
                "Petal Length must be between 1.0 and 6.9."
            )

        return value

    def clean_petal_width(self):
        value = self.cleaned_data["petal_width"]

        if value < 0.1 or value > 2.5:
            raise forms.ValidationError(
                "Petal Width must be between 0.1 and 2.5."
            )

        return value
