$(document).ready(function () {
    console.log("Jquery running");
    let uploadedFileName = "";

    $("#upBtn").click(function (e) {
        e.preventDefault();
        console.log("Button clicked");

        const csv_file = $("#csv_file")[0].files[0];
        const csrfmiddlewaretoken = $("input[name=csrfmiddlewaretoken]").val();

        let formData = new FormData();
        formData.append("csv_file", csv_file);
        formData.append("csrfmiddlewaretoken", csrfmiddlewaretoken);

        $.ajax({
            url: "/csv-upload/",
            method: "POST",
            data: formData,
            processData: false,
            contentType: false,

            success: function (response) {
                console.log(response);
                console.log(typeof response);

                if (response.status == false) {
                    showMessage(response.message, "red");
                    return;
                }
                showMessage(response.message, "green");

                uploadedFileName = response.file_name;

                $("#categoryDropdown").prop("disabled", false);
                $("#analyzeBtn").prop("disabled", false);
                $("#predictionFieldset").prop("disabled", false);

                $("#categoryDropdown").html(
                    '<option selected disabled>Select Category</option>'
                );

                for (let i = 0; i < response.category.length; i++) {
                    $("#categoryDropdown").append(
                        `<option value="${response.category[i]}">${response.category[i]}</option>`
                    );
                }
            },
            error: function () {
                alert("There is an error");
            }
        });
    });

    $("#analyzeBtn").click(function (e) {
        e.preventDefault();
        const category = $("#categoryDropdown").val();

        if (!category) {
            showMessage("Select Category", "red");
            return;
        }
        loadReport(1, true);
    });

    $(document).on("click", ".page-btn", function () {
        const page = $(this).data("page");
        loadReport(page);
    });

    function loadReport(page = 1, showSuccessMessage = false) {
        const category = $("#categoryDropdown").val();
        const csrfmiddlewaretoken = $("input[name=csrfmiddlewaretoken]").val();
        $.ajax({
            url: "/csv-upload/analyze/",
            method: "POST",
            data: {
                category: category,
                file_name: uploadedFileName,
                page: page,
                csrfmiddlewaretoken: csrfmiddlewaretoken,
            },
            success: function (response) {
                if (showSuccessMessage){
                    showMessage(response.message, "green");
                }

                let table = '<table class="table table-bordered table-striped">';
                table += '<thead><tr>';

                for (let i = 0; i < response.display_columns.length; i++) {
                    table += `<th>${response.display_columns[i]}</th>`;
                }
                table += '</tr></thead>';
                table += '<tbody>';

                for (let i = 0; i < response.records.length; i++) {
                    table += '<tr>';

                    for (let j = 0; j < response.columns.length; j++) {
                        let column = response.columns[j];
                        table += `<td>${response.records[i][column]}</td>`;
                    }
                    table += '</tr>';
                }
                table += '</tbody></table>';

                $("#tableContainer").html(table);

                // Pagination buttons
                let pagination = '';

                if (response.has_previous) {
                    pagination += `
                        <button class="btn btn-outline-primary page-btn"
                                data-page="${response.current_page - 1}">
                            ← Previous
                        </button>
                    `;
                }
                pagination += `
                    <span class="badge bg-primary fs-6 px-3 py-2">
                        Page ${response.current_page} of ${response.total_pages}
                    </span>
                `;
                if (response.has_next) {
                    pagination += `
                        <button class="btn btn-outline-primary page-btn"
                                data-page="${response.current_page + 1}">
                            Next →
                        </button>
                    `;
                }
                $("#paginationContainer").html(pagination);
            },
            error: function () {
                alert("Error while generating report");
            }
        });
    }


    // ================= Prediction AJAX =================

    $("#predictBtn").click(function (e) {
        console.log("Prediction Button clicked")
        e.preventDefault();

        // Clear previous field errors
        $(".text-danger").text("");

        // Hide previous prediction
        $("#predictionResult").hide();

        // Create FormData from the form
        let formData = new FormData($("#predictionForm")[0]);

        // Add CSRF token
        formData.append("csrfmiddlewaretoken", $("input[name=csrfmiddlewaretoken]").val());

        $.ajax({
            url: "/csv-upload/predict/",
            method: "POST",
            data: formData,
            processData: false,
            contentType: false,

            success: function (response) {
                if (response.status) {
                    $("#predictionResult")
                        .removeClass("alert-danger")
                        .addClass("alert-success")
                        .html(
                            `<strong>Predicted Species :</strong> ${response.prediction}`
                        )
                        .show();

                } 
                else {
                    if (response.errors.sepal_length) {
                        $("#sepal_length_error").text(
                            response.errors.sepal_length[0]
                        );
                    }

                    if (response.errors.sepal_width) {
                        $("#sepal_width_error").text(
                            response.errors.sepal_width[0]
                        );
                    }
                    if (response.errors.petal_length) {
                        $("#petal_length_error").text(
                            response.errors.petal_length[0]
                        );
                    }
                    if (response.errors.petal_width) {
                        $("#petal_width_error").text(
                            response.errors.petal_width[0]
                        );
                    }
                }
            },
            error: function () {
                $("#predictionResult")
                    .removeClass("alert-success")
                    .addClass("alert-danger")
                    .html("Something went wrong.")
                    .show();

            }

        });

    });


    function showMessage(message, color) {
    $("#uploadMessage")
        .text(message)
        .css("color", color)
        .fadeIn()
        .delay(2000)
        .fadeOut();
    }
});