import pandas as pd
import pickle

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score


def train_model(csv_path):
    # Load Dataset
    df = pd.read_csv(csv_path)
    print("Dataset Loaded Successfully")
    print(df.head())
    print("IRIS dataset--------------------------------", csv_path)

    # Target (Y) is the last column
    target_column = df.columns[-1]
    y = df[target_column]

    # Features (X)
    X = df.drop(target_column, axis=1)

    # Drop ID column if it exists in features
    for id_col in ["Id", "id"]:
        if id_col in X.columns:
            X = X.drop(id_col, axis=1)

    # Train Test Split
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train Decision Tree Classifier
    model = DecisionTreeClassifier(random_state=42)
    model.fit(X_train, y_train)

    # Prediction
    y_pred = model.predict(X_test)

    # Accuracy
    accuracy = accuracy_score(y_test, y_pred)
    print("Accuracy :", accuracy)

    # Save Model
    with open("ml/model.pkl", "wb") as file:
        pickle.dump(model, file)

    print("Model Saved Successfully")

    return model


if __name__ == "__main__":
    train_model("ml/IRIS.csv")
