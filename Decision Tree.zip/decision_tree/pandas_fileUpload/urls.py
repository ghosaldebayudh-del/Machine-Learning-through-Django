from django.contrib import admin
from django.urls import path, include
from csv_upload import views

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.home, name="home"),
    path("csv-upload/", include("csv_upload.urls"))
]
